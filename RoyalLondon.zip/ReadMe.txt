P Galvin 
Sunday 11 June 2017
====================

Console Application RoyalLondon.exe

Runs from Windows command line.
Input arguements are source data file (type csv), output file (type xml).

Format: royallondon inputfilename outputfilename

When running outputs details read to console.
Final output is a count of policies read.
At end prompts user to hit return to finish.

Resultant output file contains policy numbers and maturity values.