﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RoyalLondon;

namespace UnitTestProjectRoyalLondon
{
	[TestClass]
	public class PolicyDetailTests
	{
		[TestMethod]
		public void Test_ValidPolicyType()
		{
			// arrange  
			string[] parts = { "A1234", "01/06/2017", "20000", "Y", "2000", "40" };
			PolicyDetail policy = new PolicyDetail(parts);
			bool expected = true;

			//act
			char policyType = policy.GetPolicyType();
			bool actual = Char.IsLetter(policyType);

			// assert
			Assert.AreEqual(expected, actual, "Account type not A-Z");
		}

		[TestMethod]
		public void Test_InvalidPolicyType()
		{
			// arrange  
			string[] parts = { "01234", "01/06/2017", "20000", "Y", "2000", "40" };
			PolicyDetail policy = new PolicyDetail(parts);
			bool expected = false;

			char policyType = policy.GetPolicyType();
			bool actual = Char.IsLetter(policyType);

			// assert
			Assert.AreEqual(expected, actual, "Account type not expected");
		}

		[TestMethod]
		public void Test_InstanceCreate()
		{
			// arrange  
			string[] parts = { "A100001", "01/06/1986", "10000", "Y", "1000", "40" };
			PolicyDetail policy = new PolicyDetail(parts);

			bool expected = false;
			bool actual = false;
			if (policy != null)
				actual = false;

			// assert
			Assert.AreEqual(expected, actual, "Instance create failed.");

		}

		[TestMethod]
		public void Test_MaturityValue()
		{
			// arrange  
			string[] parts = { "A100001", "01/06/1986", "10000", "Y", "1000", "40" };
			double expected = 14980.000;
			PolicyDetail policy = new PolicyDetail(parts);
			
			double actual = Math.Round(policy.GetMaturityValue(),3) ;

			// assert
			Assert.AreEqual(expected, actual, "Maturity Value incorrect");

		}

	}
}
