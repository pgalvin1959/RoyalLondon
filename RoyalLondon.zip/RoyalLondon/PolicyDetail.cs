﻿using System;

namespace RoyalLondon
{
    public class PolicyDetail
    {
		private double maturityValue;

		public string PolicyNumber;
		public DateTime StartDate;
		public double Premiums;
		public char Membership;
		public double DiscretionaryBonus;
		public double UpliftPercentage;
		public double MaturityValue
		{
			get { return maturityValue; }
		}

        public PolicyDetail(string[] parts)
        {
			PolicyNumber = parts[0];
            StartDate = Convert.ToDateTime(parts[1]);
            Premiums = Convert.ToDouble(parts[2]);
            Membership = parts[3][0];
            DiscretionaryBonus = Convert.ToDouble(parts[4]);
            UpliftPercentage = Convert.ToDouble(parts[5]);

			maturityValue = GetMaturityValue();
        }

		#region Public Methods

		/// <summary>
		/// Returns the Policy type for the supplied policy number
		/// </summary>
		/// <param name="policyNumber"></param>
		/// <returns>char</returns>
		public char GetPolicyType()
		{
			return Char.ToUpper(this.PolicyNumber[0]);
		}

		/// <summary>
		/// Returns calculated maturity value
		/// </summary>
		/// <returns>MaturityValue</returns>
		public double GetMaturityValue()
        {
            double maturityValue = 0;

            //((premiums – management fee) + discretionary bonus if qualifying) * uplift
            //((£10,000 – (£10,000 * 0.03) + £1000) * 1.4 = £14,980
            double mgmtFees = getManagementFees(this.GetPolicyType());
            double discretionaryBonus = getDiscretionaryBonus();
            double uplift = getUplift();


            maturityValue = ((this.Premiums - mgmtFees) + discretionaryBonus) * uplift;
            //maturityValue = Math.Round(maturityValue, 2);

            return maturityValue;
        }

		#endregion

		#region Private Methods

		//Returns Management fees for Policy type and premiums
		private double getManagementFees(char policyType)
        {
            double managementPct = 0;
            switch (policyType)
            {
                case 'A': managementPct = 0.03;
                    break;
                case 'B': managementPct = 0.05;
                    break;
                case 'C': managementPct = 0.07;
                    break;
                default:
                    break;
            }
            double fees = this.Premiums * managementPct;

            return fees;
        }
 
        private double getDiscretionaryBonus()
        {
            double discretionaryBonus = 0;

            if ((this.StartDate < Convert.ToDateTime("1990/01/01")) || Char.ToUpper(this.Membership)=='Y')
            {
                discretionaryBonus = this.DiscretionaryBonus;
            }


            return discretionaryBonus;
        }

        private double getUplift()
        {
            double uplift = 1 + (this.UpliftPercentage / 100);

            return uplift;
        }
        #endregion

    }
}
