﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml;

namespace RoyalLondon
{
    class Program
    {
        static void Main(string[] args)
        {
            string inputFile, outputFile;
            string policyDetailsLine;
            int policyCount;
            string[] parts;

            if (args == null || args.Length==0)
            {
                Console.WriteLine("Error - argument[0] missing. Maturity data input file!"); // Check for input file
                Console.WriteLine("Error - argument[1] missing. Maturity data output file!"); // Check for output file
            }
            else if (args.Length==1)
            {
                Console.WriteLine("Error - argument[1] missing. Maturity data output file!"); // Check for output file
            }
            else
            {
                inputFile = args[0];
                outputFile = args[1];

                //Check that input file exists in the specified path.
                if (!File.Exists(inputFile))
                {
                    Console.WriteLine("Error - Maturity data file not found!");
                }
                //Check that output file does NOT exist in the specified path.
                if (File.Exists(outputFile))
                {
                    Console.WriteLine("Error - Maturity data output file already exists!");
                }
                else
                {
                    using (XmlWriter writer = XmlWriter.Create(outputFile))
                    {
                        writer.WriteStartDocument();
                        writer.WriteStartElement("Policies");

                        //Input file format is one header line followed by at least one policy detail line
                        using (StreamReader reader = new StreamReader(inputFile))
                        {
                            policyDetailsLine = "";
                            policyCount = 0;
                            while ((policyDetailsLine = reader.ReadLine()) != null)
                            {
                                //First line is a header so skip past it.
                                if (policyCount > 0)
                                {
                                    // Split the details out
                                    parts = policyDetailsLine.Split(',');

                                    PolicyDetail policy = new PolicyDetail(parts);
									
                                    Console.WriteLine(policyDetailsLine);

                                    writer.WriteStartElement("Policy");
                                    writer.WriteElementString("PolicyNumber", policy.PolicyNumber);
                                    writer.WriteElementString("MaturityValue", policy.MaturityValue.ToString());
                                    writer.WriteEndElement(); //Policy

									//policy = null;
									Array.Clear(parts, 0, parts.Length);
								}
                                policyCount++;
                            }
                            writer.WriteEndElement(); //Policies
                            writer.WriteEndDocument();
                        }

                        switch (policyCount)
                        {
                            case 0:
                                Console.WriteLine("Error - Maturity data file empty!");
                                break;
                            case 1:
                                Console.WriteLine("Error - Maturity data file has header line but no policy data!");
                                break;

                            default:
                                Console.WriteLine("\r\nNumber of policies read: " + (policyCount - 1));
                                break;
                        }

                    }
                }


            }
            Console.WriteLine("\r\n Hit return to finish.");
            Console.ReadLine();

        }
    }
}

